﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace P211_CSharp_SLQ
{
    public partial class CountriesUpdate : Form
    {
        readonly string connString = ConfigurationManager.ConnectionStrings["default"].ConnectionString;

        public CountriesUpdate()
        {
            InitializeComponent();
        }

        private void CountriesUpdate_Load(object sender, EventArgs e)
        {

            using(SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();

                string commandText = "select * from Countries";
                using (SqlCommand sqlCommand = new SqlCommand(commandText, conn))
                {
                    using (SqlDataReader reader = sqlCommand.ExecuteReader())
                    {
                        if(reader.HasRows)
                        {
                            while(reader.Read())
                            {
                                cmbCountries.Items.Add(reader["Name"]);
                            }
                        }
                    }
                }
            }
        }

        private void CmbCountries_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCountry = cmbCountries.Text;

            txtCountry.Text = selectedCountry;
        }

        private void updateSingleCountry(object sender, EventArgs e)
        {
            string updatedCountryName = txtCountry.Text.Trim();
            string oldCountryName = cmbCountries.Text;

            if(updatedCountryName == "")
            {
                MessageBox.Show("New country name should be filled.");
                return;
            }

            if(oldCountryName.Trim() == "")
            {
                MessageBox.Show("Select country to update.");
                return;
            }

            using(SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                string commandText = $"select * from Countries where Name = '{updatedCountryName}'";

                using(SqlCommand sqlCommand = new SqlCommand(commandText, conn))
                {
                    using(SqlDataReader reader = sqlCommand.ExecuteReader())
                    {
                        if(reader.HasRows)
                        {
                            MessageBox.Show("Country with this name already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    sqlCommand.CommandText = 
                        $"update Countries set Name = '{updatedCountryName}' where Name = '{oldCountryName}'";

                    int rowsAffected = sqlCommand.ExecuteNonQuery();

                    if(rowsAffected > 0)
                    {
                        MessageBox.Show("Country successfully updated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    else
                    {
                        MessageBox.Show("No country exists with this name.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
            }
        }
    }
}
